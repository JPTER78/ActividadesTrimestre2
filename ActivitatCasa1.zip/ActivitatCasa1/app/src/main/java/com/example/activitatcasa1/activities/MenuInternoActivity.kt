package com.example.activitatcasa1.activities

import android.os.Bundle
import android.view.LayoutInflater
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.activitatcasa1.R
import com.example.activitatcasa1.databinding.ActivityMenuInternoBinding
import com.example.activitatcasa1.databinding.MenuBinding
import com.example.activitatcasa1.pojos.Cliente

class MenuInternoActivity : AppCompatActivity() {

    private lateinit var binding:ActivityMenuInternoBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        val cliente = intent.getSerializableExtra("cliente") as Cliente

        binding = ActivityMenuInternoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.appbar)

        binding.textViewGitano.text = binding.textViewGitano.text.toString() + " " + cliente.getNombre()

        binding.button4.setOnClickListener {

            finishAffinity()

        }

        binding.button2.setOnClickListener {

            finishAffinity()

        }

        binding.button5.setOnClickListener {

            finishAffinity()

        }

        binding.button6.setOnClickListener {

            finishAffinity()

        }

    }
}