package com.example.activitatcasa1.activities

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.activitatcasa1.R
import com.example.activitatcasa1.bd.MiBD
import com.example.activitatcasa1.bd.MiBancoOperacional
import com.example.activitatcasa1.databinding.MenuBinding
import com.example.activitatcasa1.pojos.Cliente

class Menu : AppCompatActivity() {

    private lateinit var binding: MenuBinding

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        binding = MenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button.setOnClickListener {

            val campoNif = binding.editTextText.text.toString()
            val campoContrasenya = binding.editTextTextPassword.text.toString()

            val banco = MiBancoOperacional.getInstance(this)

            val clienteTemporal = Cliente(campoNif, campoContrasenya)

            val clienteValidado = banco?.login(clienteTemporal)

            if (clienteValidado != null) {

                println("Pitudoo")
                val intent = Intent(this, MenuInternoActivity::class.java)
                intent.putExtra("cliente", clienteValidado)
                startActivity(intent)

            } else { println("No va") }

        }

    }

}